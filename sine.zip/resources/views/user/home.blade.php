@extends('master')

@section('content-header')
<h1>
<b>Crear colegio</b>
<small>crear nuevo colegio</small>
</h1>
<ol class="breadcrumb">
    <li><a href="{{ url('/') }}"><i class="fa fa-dashboard"></i><b>Principal</b></a></li>
    <li class="active">Crear nuevo colegio</li>
</ol>
@endsection


@section('content')

<div class="row">
  
</div>{{-- END ROW --}}

@endsection
{{-- END CONTET --}}