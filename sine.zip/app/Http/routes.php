<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/
Route::get('login', 'Auth\AuthController@getLogin');
Route::post('login', 'Auth\AuthController@postLogin');
Route::get('logout', 'Auth\AuthController@getLogout');

Route::group(['middleware' => 'auth'], function()
{
	Route::get('prueba', function () {return view('home');});

	Route::get('/', function () {return view('master');});
	Route::get('user', 'UsuarioController@createUser');
	Route::post('user', 'UsuarioController@saveUser');
	Route::post('cargarUsuarios', 'UsuarioController@cargarUsuarios');
	Route::get('estudiante/{idCurso}', 'UsuarioController@estudiante');
	Route::post('estudiante', 'UsuarioController@saveEstudiante');
	Route::get('updateEstudiante/{idEstudiante}', 'UsuarioController@updateEstudiante');
	Route::post('updateEstudiante', 'UsuarioController@saveUpdateEstudiante');
	Route::post('deleteUser', 'UsuarioController@deleteUser');
	Route::post('cargarDocente', 'UsuarioController@cargarDocente');
	Route::post('saveDocente', 'UsuarioController@saveDocente');
	//RUTAS DE COLEGIO//
	Route::get('adminColegio/{id}','ColegioController@colegio');
	Route::get('colegio','ColegioController@crearColegio');
	Route::post('colegio','ColegioController@saveColegio');
	Route::get('listarColegio','ColegioController@listarColegio');
	//RUTAS CURSO
	Route::get('curso/{id}','CursoController@crearCurso');
	Route::get('frmcurso/{id}','CursoController@fomrCurso');
	Route::post('curso','CursoController@saveCurso');
	Route::get('asignarMateria/{id}','CursoController@asignarMateria');
	Route::get('administrarCurso/{id}', 'CursoController@administrarCurso');
	//RUTAS MATERIA
	Route::get('frmmateria/{id}', 'MateriaController@fomrmateria');
	Route::post('materia', 'MateriaController@saveMateria');
	Route::get('modificarMateria/{id}', 'MateriaController@modificarMateria');
	Route::post('updatemateria', 'MateriaController@updatemateria');
	Route::post('deleteMateria', 'MateriaController@deleteMateria');
	Route::post('asignarMateria', 'MateriaController@asignarMateria');
	Route::post('desasignarMateria', 'MateriaController@desasignarMateria');
	Route::get('registrarDocente/{idColegio}', 'MateriaController@registrarDocente');
	Route::get('asignarDocente/{idmateriaCurso}', 'MateriaController@asignarDocente');
	Route::post('saveAsignarDocente', 'MateriaController@saveAsignarDocente');
});



